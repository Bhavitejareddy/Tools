"""
STEP 3 — Train & Compare ResNet50 vs EfficientNetB0
=====================================================
Trains BOTH models on your dataset and saves both.
Step 4 will compare them on the test set.

Usage:
    python step3_train.py --data_dir dataset_split --output_dir output

    Train only one model:
    python step3_train.py --data_dir dataset_split --output_dir output --model resnet50
    python step3_train.py --data_dir dataset_split --output_dir output --model efficientnetb0

Pretrained weights (download on any internet machine, transfer via USB):
    python -c "
    import torch
    from torchvision.models import resnet50, ResNet50_Weights, efficientnet_b0, EfficientNet_B0_Weights
    torch.save(resnet50(weights=ResNet50_Weights.IMAGENET1K_V2).state_dict(),           'resnet50_imagenet.pth')
    torch.save(efficientnet_b0(weights=EfficientNet_B0_Weights.IMAGENET1K_V1).state_dict(), 'efficientnetb0_imagenet.pth')
    print('Both saved.')
    "

Output:
    output/
    ├── resnet50/
    │   ├── best_model.pth
    │   ├── training_log.csv
    │   └── training_curves.png
    ├── efficientnetb0/
    │   ├── best_model.pth
    │   ├── training_log.csv
    │   └── training_curves.png
    └── class_names.txt
"""

import os, sys, csv, time, copy, argparse
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms, models

try:
    from tqdm import tqdm
    USE_TQDM = True
except ImportError:
    USE_TQDM = False

# ─── SETTINGS ───────────────────────────────
NUM_CLASSES  = 5
IMAGE_SIZE   = 224
BATCH_TRAIN  = 16
BATCH_VAL    = 32
NUM_WORKERS  = 0
WEIGHT_DECAY = 1e-4
P1_EPOCHS    = 15;  P1_LR = 1e-3
P2_EPOCHS    = 20;  P2_LR = 1e-5
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD  = [0.229, 0.224, 0.225]

# ─── TRANSFORMS ─────────────────────────────
def get_transforms():
    train_tf = transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.RandomHorizontalFlip(0.5),
        transforms.RandomRotation(15),
        transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.2),
        transforms.RandomAffine(0, translate=(0.1,0.1), scale=(0.85,1.15)),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    val_tf = transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    return train_tf, val_tf

# ─── DATA ────────────────────────────────────
def load_data(data_dir, train_tf, val_tf):
    train_ds = datasets.ImageFolder(os.path.join(data_dir,"train"), transform=train_tf)
    val_ds   = datasets.ImageFolder(os.path.join(data_dir,"val"),   transform=val_tf)
    train_loader = DataLoader(train_ds, batch_size=BATCH_TRAIN, shuffle=True,  num_workers=NUM_WORKERS)
    val_loader   = DataLoader(val_ds,   batch_size=BATCH_VAL,   shuffle=False, num_workers=NUM_WORKERS)
    print(f"  Classes   : {train_ds.classes}")
    print(f"  Train set : {len(train_ds)} images")
    print(f"  Val set   : {len(val_ds)} images\n")
    return train_loader, val_loader, train_ds.classes

# ─── MODEL BUILDERS ──────────────────────────
def build_resnet50(weights_path):
    m = models.resnet50(weights=None)
    if weights_path and os.path.exists(weights_path):
        m.load_state_dict(torch.load(weights_path, map_location="cpu"))
        print(f"  ResNet50: loaded {weights_path}")
    else:
        print(f"  ResNet50: WARNING no weights found, training from scratch")
    m.fc = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.fc.in_features, NUM_CLASSES))
    return m

def build_efficientnetb0(weights_path):
    m = models.efficientnet_b0(weights=None)
    if weights_path and os.path.exists(weights_path):
        m.load_state_dict(torch.load(weights_path, map_location="cpu"))
        print(f"  EfficientNetB0: loaded {weights_path}")
    else:
        print(f"  EfficientNetB0: WARNING no weights found, training from scratch")
    in_feat = m.classifier[1].in_features
    m.classifier = nn.Sequential(nn.Dropout(0.3), nn.Linear(in_feat, NUM_CLASSES))
    return m

# ─── FREEZE / UNFREEZE ───────────────────────
def freeze_resnet(m):
    for n, p in m.named_parameters(): p.requires_grad = ("fc" in n)
    print(f"  Frozen backbone. Trainable: {sum(p.numel() for p in m.parameters() if p.requires_grad):,}")

def unfreeze_resnet(m, n=2):
    unlock = set(["layer4","layer3","layer2","layer1"][:n] + ["fc"])
    for name, p in m.named_parameters():
        if any(g in name for g in unlock): p.requires_grad = True
    print(f"  Unfroze {unlock}. Trainable: {sum(p.numel() for p in m.parameters() if p.requires_grad):,}")

def freeze_efficientnet(m):
    for n, p in m.named_parameters(): p.requires_grad = ("classifier" in n)
    print(f"  Frozen backbone. Trainable: {sum(p.numel() for p in m.parameters() if p.requires_grad):,}")

def unfreeze_efficientnet(m, n_blocks=3):
    unfreeze_from = 9 - n_blocks
    for name, p in m.named_parameters():
        if "classifier" in name:
            p.requires_grad = True
        elif "features" in name:
            try:
                if int(name.split(".")[1]) >= unfreeze_from:
                    p.requires_grad = True
            except: pass
    print(f"  Unfroze last {n_blocks} blocks. Trainable: {sum(p.numel() for p in m.parameters() if p.requires_grad):,}")

# ─── EPOCH ───────────────────────────────────
def run_epoch(model, loader, criterion, optimizer, is_train):
    model.train() if is_train else model.eval()
    loss_sum = correct = total = 0
    it = tqdm(loader, leave=False) if USE_TQDM else loader
    with torch.set_grad_enabled(is_train):
        for imgs, labels in it:
            out  = model(imgs)
            loss = criterion(out, labels)
            if is_train:
                optimizer.zero_grad(); loss.backward(); optimizer.step()
            loss_sum += loss.item() * imgs.size(0)
            correct  += (out.argmax(1) == labels).sum().item()
            total    += imgs.size(0)
    return loss_sum/total, correct/total

# ─── PHASE ───────────────────────────────────
def train_phase(model, tr, vl, crit, opt, sch, epochs, phase, mname, log, outdir):
    best_acc, best_wt = 0.0, copy.deepcopy(model.state_dict())
    best_path = os.path.join(outdir, mname, "best_model.pth")
    print(f"\n  [{mname}] {phase} — {epochs} epochs")
    print(f"  {'─'*50}")
    for ep in range(1, epochs+1):
        t0 = time.time()
        tl, ta = run_epoch(model, tr, crit, opt, True)
        vl_, va = run_epoch(model, vl, crit, None, False)
        sch.step(vl_)
        mark = ""
        if va > best_acc:
            best_acc = va; best_wt = copy.deepcopy(model.state_dict())
            torch.save(best_wt, best_path); mark = "  ← best"
        print(f"  Ep {ep:2d}/{epochs}  loss={tl:.3f} acc={ta:.3f}  |  val_loss={vl_:.3f} val_acc={va:.3f}  ({time.time()-t0:.0f}s){mark}")
        log.append([phase, ep, round(tl,4), round(ta,4), round(vl_,4), round(va,4)])
    print(f"\n  [{mname}] Best val acc: {best_acc:.4f}")
    return best_wt, best_acc

# ─── PLOT ────────────────────────────────────
def plot_curves(log, mname, outdir):
    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        p1 = [r for r in log if r[0]=="Phase1"]
        p2 = [r for r in log if r[0]=="Phase2"]
        fig,(a1,a2) = plt.subplots(1,2,figsize=(12,4))
        for rows,lbl,col in [(p1,"Phase1","steelblue"),(p2,"Phase2","coral")]:
            if not rows: continue
            ep=[r[1] for r in rows]
            a1.plot(ep,[r[2] for r in rows],"--",color=col,alpha=0.6)
            a1.plot(ep,[r[4] for r in rows],"-", color=col,label=lbl)
            a2.plot(ep,[r[3] for r in rows],"--",color=col,alpha=0.6)
            a2.plot(ep,[r[5] for r in rows],"-", color=col,label=lbl)
        a1.set_title("Loss");a1.legend();a2.set_title("Accuracy");a2.legend()
        plt.suptitle(f"{mname} — Training Curves"); plt.tight_layout()
        p = os.path.join(outdir, mname, "training_curves.png")
        plt.savefig(p, dpi=150); plt.close(); print(f"  Curves → {p}")
    except Exception as e: print(f"  Plot skipped: {e}")

# ─── TRAIN ONE MODEL ─────────────────────────
def train_model(mname, model, freeze_fn, unfreeze_fn, tr, vl, crit, p1_ep, p2_ep, outdir):
    os.makedirs(os.path.join(outdir, mname), exist_ok=True)
    log = []
    print(f"\n{'='*55}\n  Training: {mname}\n{'='*55}")

    freeze_fn(model)
    opt1 = optim.Adam(filter(lambda p:p.requires_grad, model.parameters()), lr=P1_LR, weight_decay=WEIGHT_DECAY)
    sch1 = optim.lr_scheduler.ReduceLROnPlateau(opt1, patience=3, factor=0.5)
    bwt, acc1 = train_phase(model, tr, vl, crit, opt1, sch1, p1_ep, "Phase1", mname, log, outdir)

    model.load_state_dict(bwt)
    unfreeze_fn(model)
    opt2 = optim.Adam(filter(lambda p:p.requires_grad, model.parameters()), lr=P2_LR, weight_decay=WEIGHT_DECAY)
    sch2 = optim.lr_scheduler.ReduceLROnPlateau(opt2, patience=4, factor=0.5)
    bwt2, acc2 = train_phase(model, tr, vl, crit, opt2, sch2, p2_ep, "Phase2", mname, log, outdir)

    model.load_state_dict(bwt2)
    torch.save(model.state_dict(), os.path.join(outdir, mname, "final_model.pth"))

    with open(os.path.join(outdir, mname, "training_log.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["phase","epoch","train_loss","train_acc","val_loss","val_acc"]); w.writerows(log)

    plot_curves(log, mname, outdir)
    return max(acc1, acc2)

# ─── MAIN ────────────────────────────────────
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir",          required=True)
    p.add_argument("--output_dir",        default="output")
    p.add_argument("--resnet_weights",    default="resnet50_imagenet.pth")
    p.add_argument("--efficient_weights", default="efficientnetb0_imagenet.pth")
    p.add_argument("--p1_epochs",         type=int, default=P1_EPOCHS)
    p.add_argument("--p2_epochs",         type=int, default=P2_EPOCHS)
    p.add_argument("--model",             default="both", choices=["both","resnet50","efficientnetb0"])
    args = p.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    print(f"\n{'='*55}")
    print(f"  STEP 3 — Train Drone Size Classifier")
    print(f"  PyTorch : {torch.__version__}  |  Device: CPU")
    print(f"  Model   : {args.model}")
    print(f"{'='*55}\n")

    train_tf, val_tf = get_transforms()
    tr, vl, classes  = load_data(args.data_dir, train_tf, val_tf)
    crit    = nn.CrossEntropyLoss()
    results = {}

    with open(os.path.join(args.output_dir, "class_names.txt"), "w") as f:
        [f.write(f"{i} {c}\n") for i,c in enumerate(classes)]

    if args.model in ("both", "resnet50"):
        m = build_resnet50(args.resnet_weights)
        results["ResNet50"] = train_model(
            "resnet50", m,
            freeze_resnet,
            lambda m: unfreeze_resnet(m, 2),
            tr, vl, crit, args.p1_epochs, args.p2_epochs, args.output_dir
        )

    if args.model in ("both", "efficientnetb0"):
        m = build_efficientnetb0(args.efficient_weights)
        results["EfficientNetB0"] = train_model(
            "efficientnetb0", m,
            freeze_efficientnet,
            lambda m: unfreeze_efficientnet(m, 3),
            tr, vl, crit, args.p1_epochs, args.p2_epochs, args.output_dir
        )

    # ── Final summary
    print(f"\n{'='*55}")
    print(f"  VAL ACCURACY SUMMARY")
    print(f"  {'─'*45}")
    winner = max(results, key=results.get)
    for name, acc in results.items():
        bar  = "█" * int(acc * 30)
        mark = "  ← winner" if name == winner else ""
        print(f"  {name:20s}  {acc*100:5.1f}%  {bar}{mark}")
    print(f"\n  Run step4_eval.py next to compare on TEST set.")
    print(f"  Use --model_dir output/resnet50  OR  output/efficientnetb0")
    print(f"{'='*55}\n")

if __name__ == "__main__":
    main()
