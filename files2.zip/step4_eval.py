"""
STEP 4 — Compare ResNet50 vs EfficientNetB0 on Test Set
=========================================================
Evaluates BOTH trained models on the held-out test set
and produces a side-by-side comparison.

Usage:
    python step4_eval.py --data_dir dataset_split --output_dir output

Output:
    output/
    ├── resnet50/
    │   ├── confusion_matrix.png
    │   └── evaluation_report.txt
    ├── efficientnetb0/
    │   ├── confusion_matrix.png
    │   └── evaluation_report.txt
    └── comparison_report.txt    ← which model to use
"""

import os, argparse
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms, models

try:
    from tqdm import tqdm
    USE_TQDM = True
except ImportError:
    USE_TQDM = False

IMAGE_SIZE    = 224
NUM_CLASSES   = 5
BATCH_SIZE    = 32
NUM_WORKERS   = 0
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD  = [0.229, 0.224, 0.225]

# ─── LOAD MODELS ─────────────────────────────
def load_resnet50(model_path):
    m = models.resnet50(weights=None)
    m.fc = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.fc.in_features, NUM_CLASSES))
    m.load_state_dict(torch.load(model_path, map_location="cpu"))
    m.eval(); return m

def load_efficientnetb0(model_path):
    m = models.efficientnet_b0(weights=None)
    in_feat = m.classifier[1].in_features
    m.classifier = nn.Sequential(nn.Dropout(0.3), nn.Linear(in_feat, NUM_CLASSES))
    m.load_state_dict(torch.load(model_path, map_location="cpu"))
    m.eval(); return m

# ─── INFERENCE ───────────────────────────────
def run_inference(model, data_dir):
    tf = transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    ds     = datasets.ImageFolder(os.path.join(data_dir,"test"), transform=tf)
    loader = DataLoader(ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS)
    preds, labels = [], []
    with torch.no_grad():
        it = tqdm(loader, leave=False) if USE_TQDM else loader
        for imgs, lbls in it:
            preds.extend(model(imgs).argmax(1).tolist())
            labels.extend(lbls.tolist())
    return preds, labels, ds.classes

# ─── METRICS ─────────────────────────────────
def compute_metrics(preds, labels, classes):
    n  = len(classes)
    cm = [[0]*n for _ in range(n)]
    pc = [0]*n; pt = [0]*n
    for p, l in zip(preds, labels):
        cm[l][p] += 1; pt[l] += 1
        if p == l: pc[l] += 1
    overall = sum(pc) / len(labels)
    per_acc = [pc[i]/pt[i] if pt[i]>0 else 0.0 for i in range(n)]
    return overall, per_acc, pt, cm

# ─── REPORT ──────────────────────────────────
def print_and_save_report(mname, overall, per_acc, per_total, cm, classes, outdir):
    lines = []
    lines.append(f"\n{'='*55}")
    lines.append(f"  {mname} — Test Set Results")
    lines.append(f"{'='*55}")
    lines.append(f"\n  Overall accuracy : {overall*100:.1f}%\n")
    lines.append(f"  {'Tier':10s}  {'N':>5s}  {'Acc':>7s}  Bar")
    lines.append(f"  {'─'*45}")
    for i, cls in enumerate(classes):
        bar   = "█" * int(per_acc[i]*20)
        empty = "░" * (20 - int(per_acc[i]*20))
        lines.append(f"  {cls:10s}  {per_total[i]:5d}  {per_acc[i]*100:6.1f}%  {bar}{empty}")
    lines.append(f"\n  Confusion matrix (rows=actual, cols=predicted):")
    lines.append(f"  {'':12s}" + "".join(f"{c:>9s}" for c in classes))
    lines.append(f"  {'─'*60}")
    for i, rc in enumerate(classes):
        lines.append(f"  {rc:12s}" + "".join(f"{cm[i][j]:9d}" for j in range(len(classes))))
    report = "\n".join(lines)
    print(report)
    path = os.path.join(outdir, mname, "evaluation_report.txt")
    with open(path, "w") as f: f.write(report)
    print(f"\n  Report → {path}")

# ─── PLOT CM ─────────────────────────────────
def plot_cm(cm, classes, mname, outdir):
    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import numpy as np
        arr  = np.array(cm, dtype=float)
        norm = arr / arr.sum(axis=1, keepdims=True).clip(min=1)
        fig, ax = plt.subplots(figsize=(7,6))
        im = ax.imshow(norm, cmap="Blues", vmin=0, vmax=1)
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="Recall")
        ax.set_xticks(range(len(classes))); ax.set_xticklabels(classes, rotation=45, ha="right")
        ax.set_yticks(range(len(classes))); ax.set_yticklabels(classes)
        ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
        ax.set_title(f"{mname} — Confusion Matrix")
        for i in range(len(classes)):
            for j in range(len(classes)):
                color = "white" if norm[i,j]>0.6 else "black"
                ax.text(j,i,str(int(arr[i,j])),ha="center",va="center",color=color,fontsize=10)
        plt.tight_layout()
        p = os.path.join(outdir, mname, "confusion_matrix.png")
        plt.savefig(p,dpi=150); plt.close(); print(f"  Confusion matrix → {p}")
    except Exception as e: print(f"  Plot skipped: {e}")

# ─── COMPARE ─────────────────────────────────
def save_comparison(results, classes, outdir):
    lines = []
    lines.append(f"\n{'='*55}")
    lines.append(f"  FINAL COMPARISON — Test Set Accuracy")
    lines.append(f"{'='*55}\n")

    winner = max(results, key=lambda x: results[x]["overall"])

    for mname, res in results.items():
        acc  = res["overall"]
        bar  = "█" * int(acc*30)
        mark = "  ← USE THIS MODEL" if mname == winner else ""
        lines.append(f"  {mname:20s}  {acc*100:5.1f}%  {bar}{mark}")

    lines.append(f"\n  Per-class breakdown:")
    lines.append(f"  {'Tier':10s}" + "".join(f"  {n:>18s}" for n in results.keys()))
    lines.append(f"  {'─'*60}")
    for i, cls in enumerate(classes):
        row = f"  {cls:10s}"
        for res in results.values():
            row += f"  {res['per_acc'][i]*100:17.1f}%"
        lines.append(row)

    lines.append(f"\n  Recommendation:")
    lines.append(f"    Use output/{winner}/best_model.pth for your pipeline.")
    lines.append(f"\n  To use in your Stage 2 inference:")
    if "efficientnetb0" in winner.lower():
        lines.append(f"    model = models.efficientnet_b0(weights=None)")
        lines.append(f"    in_feat = model.classifier[1].in_features")
        lines.append(f"    model.classifier = nn.Sequential(nn.Dropout(0.3), nn.Linear(in_feat, 5))")
    else:
        lines.append(f"    model = models.resnet50(weights=None)")
        lines.append(f"    model.fc = nn.Sequential(nn.Dropout(0.3), nn.Linear(model.fc.in_features, 5))")
    lines.append(f"    model.load_state_dict(torch.load('output/{winner}/best_model.pth'))")

    report = "\n".join(lines)
    print(report)
    path = os.path.join(outdir, "comparison_report.txt")
    with open(path,"w") as f: f.write(report)
    print(f"\n  Comparison report → {path}\n")

# ─── MAIN ────────────────────────────────────
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir",   required=True)
    p.add_argument("--output_dir", default="output")
    p.add_argument("--model",      default="both", choices=["both","resnet50","efficientnetb0"])
    args = p.parse_args()

    print(f"\n{'='*55}")
    print(f"  STEP 4 — Evaluate & Compare")
    print(f"{'='*55}\n")

    results = {}

    model_map = {
        "resnet50":       (os.path.join(args.output_dir,"resnet50","best_model.pth"),       load_resnet50,      "resnet50"),
        "efficientnetb0": (os.path.join(args.output_dir,"efficientnetb0","best_model.pth"), load_efficientnetb0,"efficientnetb0"),
    }

    classes = None
    for mname, (mpath, loader_fn, key) in model_map.items():
        if args.model not in ("both", mname): continue
        if not os.path.exists(mpath):
            print(f"  [{mname}] SKIP — {mpath} not found"); continue

        print(f"\n  Evaluating {mname}...")
        model = loader_fn(mpath)
        preds, labels, cls = run_inference(model, args.data_dir)
        classes = cls
        overall, per_acc, per_total, cm = compute_metrics(preds, labels, cls)
        print_and_save_report(mname, overall, per_acc, per_total, cm, cls, args.output_dir)
        plot_cm(cm, cls, mname, args.output_dir)
        results[mname] = {"overall": overall, "per_acc": per_acc, "per_total": per_total, "cm": cm}

    if len(results) > 1 and classes:
        save_comparison(results, classes, args.output_dir)
    elif len(results) == 1:
        print(f"\n  Only one model evaluated. Run with --model both to compare.")

    print("  Done.\n")

if __name__ == "__main__":
    main()
