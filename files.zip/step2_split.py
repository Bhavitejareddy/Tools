"""
STEP 2 — Split Dataset
=======================
Splits cropped images into train / val / test.
Run ONCE after Step 1 is done for all 5 tiers.

Usage:
    python step2_split.py --input_dir C:\drone_project\crops --output_dir C:\drone_project\dataset_split

Expected input structure:
    crops/
    ├── nano/     (~500 cropped images)
    ├── micro/
    ├── small/
    ├── medium/
    └── large/

Output structure:
    dataset_split/
    ├── train/   nano/ micro/ small/ medium/ large/   (70%)
    ├── val/     nano/ micro/ small/ medium/ large/   (15%)
    └── test/    nano/ micro/ small/ medium/ large/   (15%)
"""

import os
import shutil
import random
import argparse
from pathlib import Path

TIERS      = ["nano", "micro", "small", "medium", "large"]
TRAIN_FRAC = 0.70
VAL_FRAC   = 0.15
SEED       = 42
SUPPORTED_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def split_tier(tier, input_dir, output_dir):
    src = Path(input_dir) / tier
    if not src.exists():
        print(f"  [SKIP] {tier}/ not found"); return

    files = sorted([
        f for f in src.iterdir()
        if f.suffix.lower() in SUPPORTED_EXTS
        and not f.name.startswith("_")   # skip contact sheets and logs
    ])

    if not files:
        print(f"  [SKIP] {tier}/ has no images"); return

    random.shuffle(files)
    n       = len(files)
    n_train = int(n * TRAIN_FRAC)
    n_val   = int(n * VAL_FRAC)

    splits = {
        "train": files[:n_train],
        "val":   files[n_train:n_train + n_val],
        "test":  files[n_train + n_val:],
    }

    for split_name, split_files in splits.items():
        dest = Path(output_dir) / split_name / tier
        dest.mkdir(parents=True, exist_ok=True)
        for f in split_files:
            shutil.copy2(f, dest / f.name)

    print(
        f"  {tier:8s}  total={n:4d}  "
        f"train={len(splits['train']):4d}  "
        f"val={len(splits['val']):4d}  "
        f"test={len(splits['test']):4d}"
    )


def main():
    parser = argparse.ArgumentParser(description="Step 2: Split dataset into train/val/test")
    parser.add_argument("--input_dir",  required=True, help="Folder with nano/micro/small/medium/large subfolders")
    parser.add_argument("--output_dir", required=True, help="Where to write split dataset")
    args = parser.parse_args()

    random.seed(SEED)

    print(f"\n{'='*55}")
    print(f"  STEP 2 — Split Dataset")
    print(f"  Input  : {args.input_dir}")
    print(f"  Output : {args.output_dir}")
    print(f"  Split  : {TRAIN_FRAC:.0%} train / {VAL_FRAC:.0%} val / {1-TRAIN_FRAC-VAL_FRAC:.0%} test")
    print(f"{'='*55}\n")

    for tier in TIERS:
        split_tier(tier, args.input_dir, args.output_dir)

    print(f"\n  Done. Run Step 3 next.\n")


if __name__ == "__main__":
    main()
