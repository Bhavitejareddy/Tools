"""
STEP 1 — Crop Pipeline
=======================
Runs best.pt (YOLO) on your raw images, crops the drone region,
resizes to 224x224, saves into output folder per tier.

Run this for EACH tier separately.

Usage (run in Command Prompt):
    python step1_crop.py --input_dir C:\drone_project\raw\nano   --output_dir C:\drone_project\crops\nano   --tier nano   --weights C:\drone_project\best.pt
    python step1_crop.py --input_dir C:\drone_project\raw\micro  --output_dir C:\drone_project\crops\micro  --tier micro  --weights C:\drone_project\best.pt
    python step1_crop.py --input_dir C:\drone_project\raw\small  --output_dir C:\drone_project\crops\small  --tier small  --weights C:\drone_project\best.pt
    python step1_crop.py --input_dir C:\drone_project\raw\medium --output_dir C:\drone_project\crops\medium --tier medium --weights C:\drone_project\best.pt
    python step1_crop.py --input_dir C:\drone_project\raw\large  --output_dir C:\drone_project\crops\large  --tier large  --weights C:\drone_project\best.pt

After each tier:
    - Open crops\{tier}\_contact_sheet.jpg and visually check crops
    - Delete any bad crops (people, cursors, wrong objects) manually
    - Aim for ~500 good crops per tier before moving to Step 2
"""

import os
import sys
import argparse
import csv
from pathlib import Path
from collections import Counter

# Check ultralytics
try:
    from ultralytics import YOLO
except ImportError:
    print("ERROR: ultralytics not installed.")
    print("       Run: pip install ultralytics")
    sys.exit(1)

import cv2
import numpy as np

# ─────────────────────────────────────────────
# SETTINGS — adjust if needed
# ─────────────────────────────────────────────
CONF_THRESH       = 0.35    # YOLO confidence threshold
MAX_BOX_AREA_FRAC = 0.15    # reject boxes covering >15% of frame (false positives)
MIN_BOX_AREA_PX   = 20 * 20 # reject boxes smaller than 20x20 px
MAX_ASPECT_RATIO  = 4.0     # reject extremely elongated boxes
MARGIN_FRAC       = 0.15    # padding around crop (15% of box size)
OUTPUT_SIZE       = 224     # final image size for EfficientNet/ResNet

SUPPORTED_EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.webp'}


# ─────────────────────────────────────────────
# SANITY FILTER
# Catches common false positives: people, UI elements, tiny noise
# ─────────────────────────────────────────────
def is_valid_box(x1, y1, x2, y2, frame_w, frame_h):
    w = x2 - x1
    h = y2 - y1
    area = w * h
    frame_area = frame_w * frame_h

    if area > MAX_BOX_AREA_FRAC * frame_area:
        return False, "too_large"
    if area < MIN_BOX_AREA_PX:
        return False, "too_small"
    if w <= 0 or h <= 0:
        return False, "degenerate"

    aspect = max(w / h, h / w)
    if aspect > MAX_ASPECT_RATIO:
        return False, "bad_aspect"

    # Person silhouette pattern: tall narrow box
    if h > 0.5 * frame_h and w < 0.4 * h:
        return False, "person_shape"

    return True, "ok"


# ─────────────────────────────────────────────
# CROP + RESIZE
# ─────────────────────────────────────────────
def crop_and_resize(img, x1, y1, x2, y2):
    h, w = img.shape[:2]
    bw, bh = x2 - x1, y2 - y1
    mx, my = bw * MARGIN_FRAC, bh * MARGIN_FRAC

    cx1 = max(0, int(x1 - mx))
    cy1 = max(0, int(y1 - my))
    cx2 = min(w, int(x2 + mx))
    cy2 = min(h, int(y2 + my))

    crop = img[cy1:cy2, cx1:cx2]
    if crop.size == 0:
        return None

    return cv2.resize(crop, (OUTPUT_SIZE, OUTPUT_SIZE), interpolation=cv2.INTER_AREA)


# ─────────────────────────────────────────────
# CONTACT SHEET — visual grid for manual review
# ─────────────────────────────────────────────
def build_contact_sheet(output_dir, tier):
    files = sorted([
        f for f in Path(output_dir).glob("*.jpg")
        if not f.name.startswith("_")
    ])
    if not files:
        return

    imgs = []
    for f in files:
        img = cv2.imread(str(f))
        if img is not None:
            imgs.append(cv2.resize(img, (128, 128)))

    cols = 8
    rows = (len(imgs) + cols - 1) // cols
    cell = 130
    grid = np.ones((rows * cell, cols * cell, 3), dtype=np.uint8) * 240

    for i, im in enumerate(imgs):
        r, c = i // cols, i % cols
        grid[r*cell+1:r*cell+129, c*cell+1:c*cell+129] = im

    out_path = os.path.join(output_dir, f"_contact_sheet_{tier}.jpg")
    cv2.imwrite(out_path, grid)
    print(f"\n  Contact sheet saved → {out_path}")
    print(f"  OPEN THIS FILE and check for bad crops before running Step 2!")


# ─────────────────────────────────────────────
# MAIN PIPELINE
# ─────────────────────────────────────────────
def run(input_dir, output_dir, tier, weights_path):
    print(f"\n{'='*55}")
    print(f"  STEP 1 — Crop Pipeline")
    print(f"  Tier    : {tier}")
    print(f"  Input   : {input_dir}")
    print(f"  Output  : {output_dir}")
    print(f"  Weights : {weights_path}")
    print(f"{'='*55}")

    # Validate
    if not os.path.exists(input_dir):
        print(f"ERROR: input_dir not found: {input_dir}"); sys.exit(1)
    if not os.path.exists(weights_path):
        print(f"ERROR: weights not found: {weights_path}"); sys.exit(1)

    os.makedirs(output_dir, exist_ok=True)

    # Collect images
    all_files = sorted([
        f for f in Path(input_dir).iterdir()
        if f.suffix.lower() in SUPPORTED_EXTS
    ])
    print(f"\nFound {len(all_files)} images\n")
    if not all_files:
        print("ERROR: No images found."); sys.exit(1)

    # Load YOLO
    print("Loading YOLO model...")
    model = YOLO(weights_path)
    print(f"Classes: {model.names}\n")

    # Process
    log_rows = []
    counts   = Counter()
    kept     = 0

    for idx, fpath in enumerate(all_files):
        fname = fpath.name
        print(f"[{idx+1:4d}/{len(all_files)}] {fname}", end=" ... ", flush=True)

        img = cv2.imread(str(fpath))
        if img is None:
            print("SKIP (unreadable)")
            log_rows.append([fname, "read_error", ""])
            counts["read_error"] += 1
            continue

        fh, fw = img.shape[:2]
        results = model.predict(str(fpath), conf=CONF_THRESH, verbose=False)
        r = results[0]

        if r.boxes is None or len(r.boxes) == 0:
            print("no detection")
            log_rows.append([fname, "no_detection", ""])
            counts["no_detection"] += 1
            continue

        # Best box by confidence
        confs = r.boxes.conf.tolist()
        boxes = r.boxes.xyxy.tolist()
        best  = max(range(len(confs)), key=lambda i: confs[i])
        x1, y1, x2, y2 = boxes[best]
        conf = confs[best]

        # Sanity filter
        ok, reason = is_valid_box(x1, y1, x2, y2, fw, fh)
        if not ok:
            print(f"REJECTED ({reason}, conf={conf:.2f})")
            log_rows.append([fname, f"rejected_{reason}", f"conf={conf:.2f}"])
            counts[f"rejected_{reason}"] += 1
            continue

        # Crop + resize
        crop = crop_and_resize(img, x1, y1, x2, y2)
        if crop is None:
            print("SKIP (empty crop)")
            log_rows.append([fname, "empty_crop", ""])
            counts["empty_crop"] += 1
            continue

        # Save
        out_name = f"{tier}_{fpath.stem}.jpg"
        cv2.imwrite(os.path.join(output_dir, out_name), crop)
        print(f"OK (conf={conf:.2f})")
        log_rows.append([fname, "kept", f"conf={conf:.2f}"])
        counts["kept"] += 1
        kept += 1

    # Save log
    log_path = os.path.join(output_dir, f"_log_{tier}.csv")
    with open(log_path, "w", newline="") as f:
        csv.writer(f).writerows([["filename","status","info"]] + log_rows)

    # Summary
    print(f"\n{'─'*55}")
    print(f"  Results for [{tier}]:")
    for status, count in counts.most_common():
        print(f"    {status:30s}: {count}")
    print(f"  KEPT: {kept} crops")
    print(f"  Log : {log_path}")

    # Contact sheet
    build_contact_sheet(output_dir, tier)

    print(f"\n  Target is ~500 good crops.")
    if kept < 300:
        print(f"  WARNING: Only {kept} crops — consider adding more source images.")
    elif kept >= 500:
        print(f"  GOOD: {kept} crops ready.")
    print(f"{'='*55}\n")


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Step 1: Crop drone images using YOLO")
    parser.add_argument("--input_dir",  required=True, help="Folder of raw images for this tier")
    parser.add_argument("--output_dir", required=True, help="Where to save 224x224 crops")
    parser.add_argument("--tier",       required=True, choices=["nano","micro","small","medium","large"])
    parser.add_argument("--weights",    required=True, help="Path to best.pt")
    args = parser.parse_args()
    run(args.input_dir, args.output_dir, args.tier, args.weights)
